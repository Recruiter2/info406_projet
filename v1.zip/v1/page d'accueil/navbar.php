<nav class="nav-bar">
    <a class="home" href="./">Page d'acceuil</a>
    <span class="spacer"></span>
    <button class="cta btn btn-primary" type="button">Créer compte</button>
    <a class="btn btn-primary" href="account.php" role="button">Compte</a>
</nav>