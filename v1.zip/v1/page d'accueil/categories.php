<div class="flex">
    <div class="container">
        <a href="#"><img src="images/camera-solid/camera-solid/128x128.png " alt="Snow">
            <div class="bottom-left">Appareil photo</div>
        </a>
    </div>
    <div class="container">
        <a href="#"><img src="images/heart-solid/heart-solid/128x128.png " alt="Snow">
            <div class="bottom-left">Santé</div>
        </a>
    </div>
    <div class="container">
        <a href="#"><img src="images/imac-solid/imac-solid/128x128.png " alt="Snow">
            <div class="bottom-left">Ordinateur</div>
        </a>
    </div>
    <div class="container">
        <a href="#"><img src="images/microwave-solid/microwave-solid/128x128.png " alt="Snow">
            <div class="bottom-left">Micro ondes</div>
        </a>
    </div>
    <div class="container">
        <a href="#"><img src="images/music-quaver-solid/music-quaver-solid/128x128.png " alt="Snow">
            <div class="bottom-left">Musique</div>
        </a>
    </div>
    <div class="container">
        <a href="#"><img src="images/phone-solid/phone-solid/128x128.png " alt="Snow">
            <div class="bottom-left">Téléphone</div>
        </a>
    </div>
</div>