<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <header class="b1">
        <?php

        include "navbar.php"
        ?>
    </header>
    <main class="flex be">
        <div class="flex50">

            <div class="flex33">
                <div class="b1 r">
                    <p>Vos commandes</p>
                </div>
                <div class="b1 r">
                    <p>Modifier mon compte</p>
                </div>
                <div class="b1 r">
                    <p>Aide</p>
                </div>
                <div class="b1 r">
                    <p>Messagerie</p>
                </div>
            </div>

        </div>