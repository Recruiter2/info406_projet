<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <header class="b1">
        <?php

        include "navbar.php"
        ?>
    </header>
    <main class="flex be">
        <div class="flex50">
            <?php
            include "categories.php";
             ?>

            <div class="flex33">
                <div class="b1 r">
                    <p>Marque du jour</p>
                </div>
                <div class="b1 r">
                    <p>Meilleures ventes</p>
                </div>
                <div class="b1 r">
                    <p>Saint Valentin</p>
                </div>
            </div>

        </div>

        <div class="b1 v">
            <p>Panier</p>
        </div>
    </main>
    <footer class="b1">
        <h5>à propos</h5>
        <a href="#">à propos</a>
    </footer>
</body>

</html>